#pragma once

namespace Xli
{
    using namespace uBase;

    /** \ingroup XliPlatform
    */
    class PlatformLib
    {
    public:
        static void Init();
    };
}